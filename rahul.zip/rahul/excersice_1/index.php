
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form with Validation</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

 <div class="form-container">


        <form class="container" action="index.php<?php echo isset($data['id']) ? '?id=' . $data['id'] : ''; ?>" method="post" enctype="multipart/form-data" onsubmit="return validate_form()">

                 <div class="form-controler">
                <label for="fname">First Name </label>
                <input type="text" name="fname" id="fname" placeholder="Enter Your First Name" value="<?php echo isset($data['fname']) ? $data['fname'] : (isset($fname) ? $fname : ''); ?>">
                <span class="error" id="first_name_error"></span>
            </div>

            <div class="form-controler">
                <label for="lname">Last Name </label>
                <input type="text" name="lname" id="lname" placeholder="Enter Your Last Name" value="<?php echo isset($data['lname']) ? $data['lname'] : (isset($lname) ? $lname : ''); ?>">
                <span class="error" id="last_name_error"></span>
            </div>

            <div class="form-controler">
                <label for="email">Email Address </label>
                <input type="text" name="email" id="email" placeholder="Enter Your Email Address" value="<?php echo isset($data['email']) ? $data['email'] : (isset($email) ? $email : ''); ?>">
                <span class="error" id="email_error"><?php echo isset($message) ? $message : ''; ?></span>
            </div>

            <div class="form-controler-dob">
                <label for="dob">Date Of Birth </label>
                <select name="dob_day" id="dob_day">
                    <option value="">Day</option>
                    <?php for ($i = 1; $i <= 31; $i++) { ?>
                        <option value="<?php echo $i; ?>" <?php echo isset($data['dob']) && date('d', strtotime($data['dob'])) == $i ? 'selected' : (isset($dob_day) && $dob_day == $i ? 'selected' : ''); ?>><?php echo $i; ?></option>
                    <?php } ?>
                </select>

                <select name="dob_month" id="dob_month">
                    <option value="">Month</option>
                    <?php for ($i = 1; $i <= 12; $i++) { ?>
                        <option value="<?php echo $i; ?>" <?php echo isset($data['dob']) && date('m', strtotime($data['dob'])) == $i ? 'selected' : (isset($dob_month) && $dob_month == $i ? 'selected' : ''); ?>><?php echo $i; ?></option>
                    <?php } ?>
                </select>

                <select name="dob_year" id="dob_year">
                    <option value="">Year</option>
                    <?php for ($i = 1970; $i <= 2020; $i++) { ?>
                        <option value="<?php echo $i; ?>" <?php echo isset($data['dob']) && date('Y', strtotime($data['dob'])) == $i ? 'selected' : (isset($dob_year) && $dob_year == $i ? 'selected' : ''); ?>><?php echo $i; ?></option>
                    <?php } ?>
                </select>
                <span class="error" id="dob_error"></span>
            </div>

           <div class="form-controler-gh">
                <label for="gender">Gender </label><br>
                <div class="gender-options">
                    <input type="radio" id="male" name="gender" value="1" <?php echo isset($data['gender']) && $data['gender'] == '1' ? 'checked' : (isset($gender) && $gender == '0' ? 'checked' : ''); ?>>
                    <label for="male">Male</label>
                    
                    <input type="radio" id="female" name="gender" value="2" <?php echo isset($data['gender']) && $data['gender'] == '2  ' ? 'checked' : (isset($gender) && $gender == '1' ? 'checked' : ''); ?>>
                    <label for="female">Female</label>
                </div>
                <span class="error" id="gender_error"></span>
            </div>

                <?php 
                $hobbies = [];
                if (isset($data['hobbies']) ) {
                    $hobbies = explode(',', $data['hobbies']);  
                } elseif (isset($_POST['hobbies']) && is_array($_POST['hobbies'])) {
                    $hobbies = $_POST['hobbies'];
                }
            ?>

            <div class="form-controler-gh">
                <label for="hobbies">Hobbies </label><br>
                <div class="hobby-options">
                    <label><input type="checkbox" name="hobbies[]" value="Reading" <?php echo in_array('Reading', $hobbies) ? 'checked' : ''; ?>> Reading</label>
                    <label><input type="checkbox" name="hobbies[]" value="Traveling" <?php echo in_array('Traveling', $hobbies) ? 'checked' : ''; ?>> Traveling</label>
                    <label><input type="checkbox" name="hobbies[]" value="Cooking" <?php echo in_array('Cooking', $hobbies) ? 'checked' : ''; ?>> Cooking</label>
                    <label><input type="checkbox" name="hobbies[]" value="Sports" <?php echo in_array('Sports', $hobbies) ? 'checked' : ''; ?>> Sports</label>
                </div>
                 <span class="error" id="hobbies_error"></span>
            </div>
            
           

            <div class="form-controler">
                <label for="address">Address </label>
                <textarea name="address" id="address" placeholder="Enter Your full Address"><?php echo isset($data['address']) ? $data['address'] : (isset($address) ? $address : ''); ?></textarea>
                <span class="error" id="address_error"></span>
            </div>

            <div class="form-controler">
                <label for="city">City </label>
                <select name="city" id="city">
                    <option value="">Select City</option>
                    <?php
                    $cities = ['Rajkot', 'Jamnagar', 'Surat', 'Gandhinagar'];
                    $selected_city = isset($data['city']) ? $data['city'] : (isset($_POST['city']) ? $_POST['city'] : '');
                    foreach ($cities as $city) {
                        $selected = ($selected_city == $city) ? 'selected' : '';
                        echo "<option value=\"$city\" $selected>$city</option>";
                    }
                    ?>
                </select><br>
                <span class="error" id="city_error"><?php echo isset($city_error) ? $city_error : ''; ?></span>
            </div>

            <div class="form-controler">
                <label for="state">State </label>
                <select name="state" id="state">
                    <option value="">Select State</option>
                    <?php
                    $states = ['Gujarat', 'Mumbai', 'UP'];
                    $selected_state = isset($data['state']) ? $data['state'] : (isset($_POST['state']) ? $_POST['state'] : '');
                    foreach ($states as $state) {
                        $selected = ($selected_state == $state) ? 'selected' : '';
                        echo "<option value=\"$state\" $selected>$state</option>";
                    }
                    ?>
                </select><br>
                <span class="error" id="state_error"><?php echo isset($state_error) ? $state_error : ''; ?></span>
            </div>

            <div class="form-controler">
                <label for="zipcode">Zipcode </label>
                <input type="text" name="zipcode" id="zipcode" placeholder="Enter Your Zipcode" value="<?php echo isset($data['zipcode']) ? $data['zipcode'] : (isset($zipcode) ? $zipcode : ''); ?>">
                <span class="error" id="zipcode_error"></span>
            </div>

            <div class="form-controler">
                <?php if (isset($data['profilepic']) && $data['profilepic']): ?>
                    <img src="./uploads/<?php echo $data['profilepic']; ?>" alt="Profile Picture" width="100" height="100"><br>
                <?php endif; ?>
                <label for="profile">Profile Picture </label>
                <input type="file" name="profile" id="profile" >
                <span class="error" id="profile_error"></span>
            </div>

            <div class="form-controler">
                <button type="submit"><?php echo isset($id) ? 'Update Record' : 'Save Record'; ?></button>
            </div>
           
        </form>
    </div>

<script src="./assets/js/script.js"></script>
</body>
</html>
