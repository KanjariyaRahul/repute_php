function validate_form() {
    
    let first_name = document.getElementById('first_name').value;
    if ('' == first_name) {
        alert('Please Enter First Name!');
        return false;
    }

 
    let email = document.getElementById('email').value;
    let email_pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
    if (!email.match(email_pattern)) {
        alert('Please enter a valid email address!');
        return false;
    }

    
    let phone = document.getElementById('phone').value;
    let phone_pattern = /^[\d]{10}$/; 
    if (!phone.match(phone_pattern)) {
        alert('Please enter a valid phone number!');
        return false;
    }

    return true;
}
