<?php

include('../config/connect.php');


include('../includes/header.php');
?>

<h1>Admin Dashboard</h1>
<p>Welcome to the admin dashboard.</p>

<?php

include('../includes/footer.php');
?>