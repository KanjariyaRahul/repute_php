function validate_form() {
    let fname = document.getElementById('fname').value.trim();
    if ('' === fname) {
        alert('Please Enter First Name!');
        document.getElementById('fname').focus();  
        return false;
    }

   
    let lname = document.getElementById('lname').value.trim();
    if ('' === lname) {
        alert('Please Enter Last Name!');
        document.getElementById('lname').focus();  
        return false;
    }

    
    let email = document.getElementById('email').value.trim();
    let email_pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
    if (!email.match(email_pattern)) {
        alert('Please enter a valid email address!');
        document.getElementById('email').focus();  
        return false;
    }

    
    let dob_day = document.getElementById('dob_day').value.trim();
    let dob_month = document.getElementById('dob_month').value.trim();
    let dob_year = document.getElementById('dob_year').value.trim();
    if ('' === dob_day || '' === dob_month || '' === dob_year) {
        alert('Please select a valid date of birth!');
        document.getElementById('dob_day').focus(); 
        return false;
    }

    
    let gender = document.querySelector('input[name="gender"]:checked');
    if (!gender) {
        alert('Please select your gender!');
        document.querySelector('input[name="gender"]').focus(); 
        return false;
    }


    let address = document.getElementById('address').value.trim();
    if ('' === address) {
        alert('Please enter your address!');
        document.getElementById('address').focus();  
        return false;
    }

   
    let city = document.getElementById('city').value.trim();
    if ('' === city) {
        alert('Please select a city!');
        document.getElementById('city').focus();  
        return false;
    }

    
    let state = document.getElementById('state').value.trim();
    if ('' === state) {
        alert('Please select a state!');
        document.getElementById('state').focus();  
        return false;
    }


    let zipcode = document.getElementById('zipcode').value.trim();
    let zipcode_pattern = /^\d{6}$/;
    if (!zipcode.match(zipcode_pattern)) {
        alert('Please enter a valid 6-digit zipcode!');
        document.getElementById('zipcode').focus(); 
        return false;
    }

    
    let profile = document.getElementById('profile').value.trim();
    if ('' === profile) {
        alert('Please upload a profile picture!');
        document.getElementById('profile').focus();  
        return false;
    } else {
        let profile_pattern = /\.(jpg|jpeg|png)$/i;
        if (!profile.match(profile_pattern)) {
            alert('Profile picture must be in JPG, JPEG, or PNG format!');
            document.getElementById('profile').focus();  
            return false;
        }
    }

    
    let hobbies = document.querySelectorAll('input[name="hobbies[]"]:checked');
    if (hobbies.length === 0) {
        alert('Please select at least one hobby!');
        document.querySelector('input[name="hobbies[]"]').focus(); 
        return false;
    }

   
    alert('Form submitted successfully!');
    return true;
}
