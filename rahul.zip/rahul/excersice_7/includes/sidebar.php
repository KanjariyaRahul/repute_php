
<body>
    <aside class="sidebar">
        <ul>
            <li><a href="index.php">User List</a></li>
            <li><a href="form.php">Add User</a></li>
        </ul>
    </aside>
</body>

