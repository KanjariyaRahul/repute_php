<?php
include('includes/header.php');
include('includes/sidebar.php');
include('config/db_operations.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $file = $_FILES['file'];

    // Upload file
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $upload_dir = 'uploads/';
    move_uploaded_file($file_tmp, $upload_dir . $file_name);

    // Insert data into the database
    saveUser($first_name, $last_name, $email, $phone, $file_name); // Assuming this function saves the data
}
?>

<div class="container">
    <h1>Add User</h1>
    <form action="form.php" method="post" enctype="multipart/form-data">
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" required><br>

        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" required><br>

        <label for="file">File:</label>
        <input type="file" id="file" name="file" required><br>

        <input type="submit" value="Submit">
    </form>
</div>

<?php
include('includes/footer.php');
?>
