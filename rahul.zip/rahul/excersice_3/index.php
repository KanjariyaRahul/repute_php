<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple Inputs with Different Events</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

    <form id="userForm">
        <label for="fname">First Name:</label>
        <input type="text" id="fname" class="input-field" placeholder="Enter your first name" onClick="handleClick()">
        <p id="fnameFeedback" class="error"></p>

        <label for="lname">Last Name:</label>
        <input type="text" id="lname" class="input-field" placeholder="Enter your last name" onFocus="handleFocus()">
        <p id="lnameFeedback" class="error"></p>

        <label for="email">Email:</label>
        <input type="email" id="email" class="input-field" placeholder="Enter your email" onBlur="blurFunction()" onfocus="focusFunction()">
        <p id="emailFeedback" class="error"></p>

        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" class="input-field" placeholder="Enter your phone number" onKeydown="handleKeydown(event)">
        <p id="phoneFeedback" class="error"></p>

        <label for="address">Address:</label>
        <input type="text" id="address" class="input-field" placeholder="Enter your address" onKeyup="handleKeyup(event)">
        <p id="addressFeedback" class="error"></p>

        <label for="zipcode">Zip Code:</label>
        <input type="text" id="zipcode" class="input-field" placeholder="Enter your zip code" onKeypress="handleKeypress(event)">
        <p id="zipcodeFeedback" class="error"></p>

        <button type="submit">Submit</button>
    </form>

    <script src="./assets/js/script.js"></script>

</body>
</html>
