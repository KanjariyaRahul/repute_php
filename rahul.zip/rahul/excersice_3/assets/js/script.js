function handleClick() {
    console.log("First Name field clicked!");
    document.getElementById("fnameFeedback").textContent = "You clicked the First Name input field.";
}

function handleFocus() {
    console.log("Last Name field focused!");
    document.getElementById("lname").classList.add("highlight");
    document.getElementById("lnameFeedback").textContent = "You focused on the Last Name input field.";
}

        function focusFunction() {
            document.getElementById("email").style.background = "yellow";
        }

        function blurFunction() {
            document.getElementById("email").style.background = "red";
        }

function handleKeydown(event) {
    console.log("Key down: " + event.key);
    document.getElementById("phoneFeedback").textContent = "Key down event: " + event.key;
}

function handleKeyup(event) {
    console.log("Key up: " + event.key);
    document.getElementById("addressFeedback").textContent = "Key up event: " + event.key;
}

function handleKeypress(event) {
    console.log("Key pressed: " + event.key);
    document.getElementById("zipcodeFeedback").textContent = "Key press event: " + event.key;
}

document.getElementById("userForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Form Submitted!");
});
