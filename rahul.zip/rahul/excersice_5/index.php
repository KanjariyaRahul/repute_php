<?php
include './config/connect.php';

$limit = 2;

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

$page = max(1, $page);

$offset = ($page - 1) * $limit;

$query = "SELECT * FROM user";
$execut = mysqli_query($conn, $query);
$total_user = mysqli_num_rows($execut);

$total_pages = ceil($total_user / $limit);

$query .= " LIMIT $limit OFFSET $offset";
$execut = mysqli_query($conn, $query);

$range = 10; 
$start = max(1, $page - floor($range / 2));
$end = min($total_pages, $start + $range - 1);


if ($end - $start < $range - 1) {
    $start = max(1, $end - $range + 1);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List with Pagination</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <style>
    .google-pagination .prev-btn {
        display: <?php echo $page > 1 ? 'inline-block': 'none';
        ?>;
    }

    .google-pagination .next-btn {
        display: <?php echo $page < $total_pages ? 'inline-block': 'none';
        ?>;
    }
</style>
</head>
<body>
    <div class="container">
        <h1>User List</h1>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = mysqli_fetch_assoc($execut)) : ?>
                    <tr>
                        <td><?php echo ($user['id']); ?></td>
                        <td><?php echo ($user['fname']); ?></td>
                        <td><?php echo ($user['email']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

       
        <div class="pagination">
            <h2>Numeric Pagination</h2><br>

            <?php if ($page > 1) : ?>
                <a href="?page=1">First</a>
                <a href="?page=<?php echo $page - 1; ?>">Previous</a>
            <?php else: ?>
                <span>First</span>
                <span>Previous</span>
            <?php endif; ?>

            <!-- Page Numbers -->
            <?php for ($i = $start; $i <= $end; $i++) : ?>
                <?php if ($i == $page) : ?>
                    <span class="current"><?php echo $i; ?></span>
                <?php else : ?>
                    <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>
  
            <?php if ($page < $total_pages) : ?>
                <a href="?page=<?php echo $page + 1; ?>">Next</a>
                <a href="?page=<?php echo $total_pages; ?>">Last</a>
            <?php else: ?>
                <span>Next</span>
                <span>Last</span>
            <?php endif; ?>
        </div>

    
         <div class="google-pagination">
            <h2>Google-style Pagination</h2><br>

            
            <span class="prev-btn">
                <a href="?page=<?php echo max(1, $page - 1); ?>">Previous</a>
            </span>

            <!-- Page Numbers -->
            <?php for ($i = $start; $i <= $end; $i++) : ?>
                <?php if ($i == $page) : ?>
                    <span class="current"><?php echo $i; ?></span>
                <?php else : ?>
                    <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <span class="next-btn">
                <a href="?page=<?php echo min($total_pages, $page + 1); ?>">Next</a>
            </span>
        </div>
    </div>
</body>
</html>
