<?php
include('./config/connect.php');

$successMessage = '';  

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $id = isset($_POST['id']) ? $_POST['id'] : null;
    $email = addslashes($_POST['email']);
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $phone = $_POST['phone'];
    $files = $_FILES['file'];

    $disallowed_extensions = ['php', 'php3', 'php4', 'php5', 'py', 'pl', 'asp', 'jsp', 'cgi', 'exe'];
    $compressed_extensions = ['tar', 'zip', 'gz', 'gzip', 'rar', '7z'];

    $upload_dir = 'uploads/';
    $error_found = false;
    $uploaded_file_paths = [];

    for ($i = 0; $i < count($files['name']); $i++) {
        $file_name = $files['name'][$i];
        $file_tmp = $files['tmp_name'][$i];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $disallowed_extensions)) {
            $error_found = true;
            echo "<script>alert('Error: The file \"$file_name\" has a disallowed extension.');</script>";
            continue;
        }

        if (!in_array($file_ext, $compressed_extensions)) {
            $file_content = file_get_contents($file_tmp);
            if (strpos($file_content, '<?php') !== false) {
                $error_found = true;
                echo "<script>alert('Error: The file \"$file_name\" contains PHP code and cannot be uploaded.');</script>";
                continue;
            }
        }

        $unique_file_name = uniqid('upload_') . '.' . $file_ext;
        $file_path = $upload_dir . $unique_file_name;

        if (move_uploaded_file($file_tmp, $file_path)) {
            $uploaded_file_paths[] = addslashes($file_path);
        } else {
            $error_found = true;
            echo "<script>alert('Error: Failed to upload file \"$file_name\".');</script>";
        }
    }

    if (!$error_found && count($uploaded_file_paths) > 0) {
        $file_paths_string = implode(",", $uploaded_file_paths);

        $query = "INSERT INTO user (first_name, last_name, email, phone , file) VALUES ('$fname', '$lname', '$email', '$phone', '$file_paths_string')";
        
        if (mysqli_query($conn, $query)) {
            mysqli_commit($conn);
            $successMessage = 'Record added successfully with files uploaded.';  
        } else {
            $error_found = true;
            echo "<script>alert('Error: Failed to update user record with file paths.');</script>";
        }
    } else {
        mysqli_rollback($conn);
        echo "<script>alert('Error: File upload failed, record not inserted.');</script>";
    }

    if (!$error_found) {
        mysqli_commit($conn);
    } else {
        mysqli_rollback($conn);
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload Form</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

    <div class="form-container">
        <h2>File Upload Form</h2>

        <form action="" method="POST" enctype="multipart/form-data" onsubmit="return validateForm(event)" id="myForm">
            <input type="hidden" name="id" value="">

            <div class="form-group">
                <label for="fname">First Name:</label>
                <input type="text" id="fname" name="fname" value="" >
                <div class="error-message" id="fname-error"></div>
            </div>

            <div class="form-group">
                <label for="lname">Last Name:</label>
                <input type="text" id="lname" name="lname" value="" >
                <div class="error-message" id="lname-error"></div>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="" >
                <div class="error-message" id="email-error"></div>
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" value="" >
                <div class="error-message" id="phone-error"></div>
            </div>

            <div class="form-group" id="file-group">
                <label for="file">Upload Files:</label>
                <div id="file-inputs">
                    <input type="file" name="file[]" onchange="displayFileNames()" multiple>
                </div>
                <input type="button" value="+" onclick="addFileInput();">
                <div class="error-message" id="file-error"></div>
                <ul id="file-names"></ul>
            </div>

            <button type="submit">Submit</button>
        </form>

        <?php if ($successMessage): ?>
            <script>
                alert("<?php echo $successMessage; ?>");
                clearForm(); 
            </script>
        <?php endif; ?>
    </div>

    <script>
        function addFileInput() {
            const fileGroup = document.getElementById('file-inputs');
            const newFileInput = document.createElement('input');
            newFileInput.type = 'file';
            newFileInput.name = 'file[]';
            newFileInput.multiple = true;
            newFileInput.onchange = displayFileNames;
            fileGroup.appendChild(newFileInput);
        }

        function displayFileNames() {
            const fileInputs = document.querySelectorAll('input[type="file"]');
            const fileNamesList = document.getElementById('file-names');
            const errorMessage = document.getElementById('file-error');
            fileNamesList.innerHTML = '';
            errorMessage.innerHTML = '';

            let filesSelected = false;

            fileInputs.forEach(input => {
                if (input.files.length > 0) {
                    filesSelected = true;
                    for (let i = 0; i < input.files.length; i++) {
                        const fileName = input.files[i].name;
                        const listItem = document.createElement('li');
                        listItem.textContent = fileName;
                        fileNamesList.appendChild(listItem);
                    }
                }
            });

            if (!filesSelected) {
                errorMessage.textContent = "No files selected.";
            }
        }

        function validateForm(event) {
            document.querySelectorAll('.error-message').forEach(function (message) {
                message.textContent = '';
            });
            document.querySelectorAll('input').forEach(function (input) {
                input.classList.remove('error-border');
            });

            let isValid = true;

            const fname = document.getElementById('fname').value;
            if (!fname) {
                document.getElementById('fname-error').textContent = 'First Name is required.';
                document.getElementById('fname').classList.add('error-border');
                document.getElementById('fname').focus();
                isValid = false;
            }

            const lname = document.getElementById('lname').value;
            if (!lname) {
                document.getElementById('lname-error').textContent = 'Last Name is required.';
                document.getElementById('lname').classList.add('error-border');
                if (isValid) document.getElementById('lname').focus();
                isValid = false;
            }

            const email = document.getElementById('email').value;
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!email || !emailPattern.test(email)) {
                document.getElementById('email-error').textContent = 'Please enter a valid email address.';
                document.getElementById('email').classList.add('error-border');
                if (isValid) document.getElementById('email').focus();
                isValid = false;
            }

            const phone = document.getElementById('phone').value;
            const phonePattern = /^[0-9]{10}$/;
            if (!phone || !phonePattern.test(phone)) {
                document.getElementById('phone-error').textContent = 'Please enter a valid 10-digit phone number.';
                document.getElementById('phone').classList.add('error-border');
                if (isValid) document.getElementById('phone').focus();
                isValid = false;
            }

            const fileInputs = document.querySelectorAll('input[type="file"]');
            const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt'];
            let fileValid = true;

            let fileSelected = false;
            fileInputs.forEach(input => {
                const files = input.files;
                if (files.length === 0) return;

                fileSelected = true;
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];
                    const fileExt = file.name.split('.').pop().toLowerCase();
                    if (!allowedExtensions.includes(fileExt)) {
                        document.getElementById('file-error').textContent = 'Only the following file types are allowed: jpg, jpeg, png, gif, pdf, txt.';
                        input.classList.add('error-border');
                        fileValid = false;
                        return;
                    }
                }
            });

            if (!fileSelected) {
                document.getElementById('file-error').textContent = 'Please select at least one file.';
                isValid = false;
            }

            if (!fileValid) {
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault();
            }
        }

        function clearForm() {
            const form = document.getElementById('myForm');
            form.reset();
            
            const fileNamesList = document.getElementById('file-names');
            fileNamesList.innerHTML = ''; 
            
            document.querySelectorAll('.error-message').forEach(function (message) {
                message.textContent = ''; 
            });

            document.querySelectorAll('input').forEach(function (input) {
                input.classList.remove('error-border'); 
            });
        }
    </script>

</body>
</html>
