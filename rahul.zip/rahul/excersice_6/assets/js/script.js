 function validateForm(event) {
            // Clear previous error messages and remove red borders
            document.querySelectorAll('.error-message').forEach(function (message) {
                message.textContent = '';
            });
            document.querySelectorAll('input').forEach(function (input) {
                input.classList.remove('error-border');
            });

            let isValid = true;

            // Validate First Name
            const fname = document.getElementById('fname').value;
            if (!fname) {
                document.getElementById('fname-error').textContent = 'First Name is required.';
                document.getElementById('fname').classList.add('error-border');
                document.getElementById('fname').focus(); 
                isValid = false;
            }

            // Validate Last Name
            const lname = document.getElementById('lname').value;
            if (!lname) {
                document.getElementById('lname-error').textContent = 'Last Name is required.';
                document.getElementById('lname').classList.add('error-border');
                if (isValid) document.getElementById('lname').focus();
                isValid = false;
            }

            // Validate Email
            const email = document.getElementById('email').value;
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!email || !emailPattern.test(email)) {
                document.getElementById('email-error').textContent = 'Please enter a valid email address.';
                document.getElementById('email').classList.add('error-border');
                if (isValid) document.getElementById('email').focus(); 
                isValid = false;
            }

            // Validate Phone
            const phone = document.getElementById('phone').value;
            const phonePattern = /^[0-9]{10}$/;
            if (!phone || !phonePattern.test(phone)) {
                document.getElementById('phone-error').textContent = 'Please enter a valid 10-digit phone number.';
                document.getElementById('phone').classList.add('error-border');
                if (isValid) document.getElementById('phone').focus(); 
                isValid = false;
            }

            // Validate File Upload
            const fileInput = document.getElementById('file');
            const files = fileInput.files;
            const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt'];
            let fileValid = true;
            if (files.length === 0) {
                document.getElementById('file-error').textContent = 'Please select at least one file.';
                fileInput.classList.add('error-border');
                if (isValid) fileInput.focus(); 
                fileValid = false;
            } else {
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];
                    const fileExt = file.name.split('.').pop().toLowerCase();
                    if (!allowedExtensions.includes(fileExt)) {
                        document.getElementById('file-error').textContent = 'Only the following file types are allowed: jpg, jpeg, png, gif, pdf, txt.';
                        fileInput.classList.add('error-border');
                        if (isValid) fileInput.focus(); 
                        fileValid = false;
                        break;
                    }
                }
            }

            if (!fileValid) {
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault(); // Prevent form submission if validation fails
            } else {
                // If the form is valid, reset the fields and display a success message
                document.getElementById('myForm').reset(); // Reset the form
                document.getElementById('file-names').innerHTML = ''; // Clear file names
                alert("Form submitted successfully!");
            }
        }

        function displayFileNames() {
            const fileInput = document.getElementById('file');
            const fileList = fileInput.files;
            const fileNamesContainer = document.getElementById('file-names');
            fileNamesContainer.innerHTML = ''; // Clear previous file names

            for (let i = 0; i < fileList.length; i++) {
                const li = document.createElement('li');
                li.textContent = fileList[i].name;
                fileNamesContainer.appendChild(li);
            }
        }