
<body>
    <aside class="sidebar">
        <ul>
            <li><a href="index.php">User List</a></li>
        </ul>
    </aside>
</body>

