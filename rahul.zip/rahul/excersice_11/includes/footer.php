

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

</style> <!-- Path to the CSS file -->
</head>
<body>
    
<footer class="footer">
    <p>&copy; 2025 User Management System</p>
</footer>

<script src="assets/js/script.js"></script>
</body>
</html>