document.addEventListener('DOMContentLoaded', function () {
    console.log('User Management System Loaded');
});
