<?php
include('includes/header.php');
include('config/db_operations.php');

$users = getAllUsers(); 
?>

<div class="container">
    <div class="sidebar">
        <?php include('includes/sidebar.php'); ?>
    </div>

    <div class="main-content">
        <h1>User List</h1>
        <h4 style="margin: 10px;">Table to Div structure conversion </h4>
        <div class="user-list">
        
            <div class="user-row user-header">
                <div class="user-cell">ID</div>
                <div class="user-cell">First Name</div>
                <div class="user-cell">Last Name</div>
                <div class="user-cell">Email</div>
                <div class="user-cell">Phone</div>
            </div>
            <?php foreach($users as $user): ?>
                <div class="user-row">
                    <div class="user-cell"><?= $user['id']; ?></div>
                    <div class="user-cell"><?= $user['first_name']; ?></div>
                    <div class="user-cell"><?= $user['last_name']; ?></div>
                    <div class="user-cell"><?= $user['email']; ?></div>
                    <div class="user-cell"><?= $user['phone']; ?></div>
                </div>z
            <?php endforeach; ?>
        </div>

    </div>
</div>

<?php
include('includes/footer.php');
?>