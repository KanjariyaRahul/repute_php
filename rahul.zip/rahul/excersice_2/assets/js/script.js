function validate_form() {
    "use strict";
    
    let hasErrors = false;
    
    document.querySelectorAll('.error').forEach(function (error) {
        error.textContent = '';
    });
    document.querySelectorAll('input, select, textarea').forEach(function (input) {
        input.style.borderColor = '#ccc';
    });

  
    const fname = document.getElementById('fname').value.trim();
    const lname = document.getElementById('lname').value.trim();
    const email = document.getElementById('email').value.trim();
    const dob_day = document.getElementById('dob_day').value.trim();
    const dob_month = document.getElementById('dob_month').value.trim();
    const dob_year = document.getElementById('dob_year').value.trim();
    const gender = document.querySelector('input[name="gender"]:checked');
    const address = document.getElementById('address').value.trim();
    const city = document.getElementById('city').value.trim();
    const state = document.getElementById('state').value.trim();
    const zipcode = document.getElementById('zipcode').value.trim();
    const profile = document.getElementById('profile').value.trim();
    const hobbies = document.querySelectorAll('input[name="hobbies[]"]:checked');
    const nameRegex = /^[a-zA-Z\s]+$/;

    // Validate First Name
    if (!fname || !nameRegex.test(fname)) {
        document.getElementById("fname_error").textContent = "First Name is required and should not contain special characters.";
        document.getElementById("fname").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("fname").focus();
        hasErrors = true;
    }

    // Validate Last Name
    if (!lname || !nameRegex.test(lname)) {
        document.getElementById("lname_error").textContent = "Last Name is required and should not contain special characters.";
        document.getElementById("lname").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("lname").focus();
        hasErrors = true;
    }

    // Validate Email
    if (!email || !/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(email)) {
        document.getElementById("email_error").textContent = "Please enter a valid email.";
        document.getElementById("email").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("email").focus();
        hasErrors = true;
    }

    // Validate Date of Birth
    if (!dob_day || !dob_month || !dob_year) {
        document.getElementById("dob_error").textContent = "Please select a valid date of birth.";
        document.getElementById("dob_day").style.borderColor = 'red';
        document.getElementById("dob_month").style.borderColor = 'red';
        document.getElementById("dob_year").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("dob_day").focus();
        hasErrors = true;
    }

    // Validate Gender
    if (!gender) {
        document.getElementById("gender_error").textContent = "Please select your gender.";
        hasErrors = true;
    }

    // Validate Address
    if (!address) {
        document.getElementById("address_error").textContent = "Please enter your address.";
        document.getElementById("address").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("address").focus();
        hasErrors = true;
    }

    // Validate City
    if (!city) {
        document.getElementById("city_error").textContent = "Please select a city.";
        document.getElementById("city").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("city").focus();
        hasErrors = true;
    }

    // Validate State
    if (!state) {
        document.getElementById("state_error").textContent = "Please select a state.";
        document.getElementById("state").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("state").focus();
        hasErrors = true;
    }

    // Validate Zipcode
    if (!zipcode || !/^\d{6}$/.test(zipcode)) {
        document.getElementById("zipcode_error").textContent = "Please enter a valid 6-digit zipcode.";
        document.getElementById("zipcode").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("zipcode").focus();
        hasErrors = true;
    }

    // Validate Profile Picture
    if (!profile) {
        document.getElementById("profile_error").textContent = "Profile picture is required.";
        document.getElementById("profile").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("profile").focus();
        hasErrors = true;
    } else if (profile && !/\.(jpg|jpeg|png)$/i.test(profile)) {
        document.getElementById("profile_error").textContent = "Profile photo must be in jpg/jpeg/png format.";
        document.getElementById("profile").style.borderColor = 'red';
        if (!hasErrors) document.getElementById("profile").focus();
        hasErrors = true;
    }


     if (hobbies.length === 0) {
        document.getElementById("hobbies_error").textContent = "Please select at least one hobby.";
        hasErrors = true;
    }
    

    // If any errors, prevent form submission
    return !hasErrors;
}
