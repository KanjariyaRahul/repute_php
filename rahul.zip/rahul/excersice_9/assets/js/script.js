function applyJsFunction() {
    const arrayStr = document.getElementById("jsInputArray").value;

    let array = arrayStr.split(',').map(val => val.trim()); 

    const functionName = document.getElementById("jsFunction").value;

    let result;
    
   
    switch (functionName) {
        // Case for 'sort' method
        case 'sort':
            array.sort((a, b) => {
                const numA = Number(a);
                const numB = Number(b);

                if (!isNaN(numA) && !isNaN(numB)) {
                    return numA - numB;
                }
                return a.localeCompare(b);
            });
            result = "JavaScript - sort(): " + array.join(", ");
            break;
        
        // Case for 'reverse' method
        case 'reverse':
            // Reverse the array order
            array.reverse();
            result = "JavaScript - reverse(): " + array.join(", ");
            break;
        
        // Case for 'push' method
        case 'push':
            // Prompt the user for a value to add to the end of the array
            const pushValue = prompt("Enter a value to push:");
            array.push(pushValue);
            result = "JavaScript - push(): " + array.join(", ");
            break;
        
        // Case for 'pop' method
        case 'pop':
            // Remove the last element from the array
            array.pop();
            result = "JavaScript - pop(): " + array.join(", ");
            break;
        
        // Case for 'length' property
        case 'length':
            // Return the length of the array
            result = "JavaScript - length: " + array.length;
            break;
        
        // Case for 'shift' method
        case 'shift':
            // Remove the first element from the array
            array.shift();
            result = "JavaScript - shift(): " + array.join(", ");
            break;
        
        // Case for 'unshift' method
        case 'unshift':
            // Prompt the user for a value to add to the beginning of the array
            const unshiftValue = prompt("Enter a value to unshift:");
            array.unshift(unshiftValue);
            result = "JavaScript - unshift(): " + array.join(", ");
            break;
        
        // Case for 'splice' method
        case 'splice':
            // Prompt the user for the index and value to replace at that index
            const spliceIndex = Number(prompt("Enter the index to splice:"));
            const spliceValue = prompt("Enter a value to replace at index " + spliceIndex + ":");
            array.splice(spliceIndex, 1, spliceValue);
            result = "JavaScript - splice(): " + array.join(", ");
            break;
        
        // Case for 'indexOf' method
        case 'indexOf':
            // Prompt the user for a value to find the index of in the array
            const indexValue = prompt("Enter a value to find index of:");
            const index = array.indexOf(indexValue);
            result = "JavaScript - indexOf(): " + (index !== -1 ? index : "Not Found");
            break;
        
        // Default case if an invalid or unrecognized function is selected
        default:
            result = "Please select a valid JavaScript function.";
            break;
    }

    
    document.getElementById("jsResult").innerText = result;
}
