<?php
// Initialize result for PHP array functions
$phpResult = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $inputArray = isset($_POST['inputArray']) ? explode(',', $_POST['inputArray']) : [];
    $function = isset($_POST['function']) ? $_POST['function'] : "";

    switch ($function) {
        case 'sort':
            sort($inputArray);
            $phpResult = "PHP - sort(): " . implode(", ", $inputArray);
            break;
        case 'rsort':
            rsort($inputArray);
            $phpResult = "PHP - rsort(): " . implode(", ", $inputArray);
            break;
        case 'asort':
            asort($inputArray);
            $phpResult = "PHP - asort(): " . implode(", ", $inputArray);
            break;
        case 'arsort':
            arsort($inputArray);
            $phpResult = "PHP - arsort(): " . implode(", ", $inputArray);
            break;
        case 'ksort':
            ksort($inputArray);
            $phpResult = "PHP - ksort(): " . implode(", ", $inputArray);
            break;
        case 'krsort':
            krsort($inputArray);
            $phpResult = "PHP - krsort(): " . implode(", ", $inputArray);
            break;
        case 'usort':
            usort($inputArray, function($a, $b) { return $a - $b; });
            $phpResult = "PHP - usort(): " . implode(", ", $inputArray);
            break;
        case 'ursort':
            ursort($inputArray, function($a, $b) { return $b - $a; });
            $phpResult = "PHP - ursort(): " . implode(", ", $inputArray);
            break;
        case 'uksort':
            uksort($inputArray, function($a, $b) { return strcmp($a, $b); });
            $phpResult = "PHP - uksort(): " . implode(", ", $inputArray);
            break;
        case 'in_array':
            $phpResult = "PHP - in_array(2): " . (in_array(2, $inputArray) ? "True" : "False");
            break;
        case 'is_array':
            $phpResult = "PHP - is_array: " . (is_array($inputArray) ? "True" : "False");
            break;
        case 'array_chunk':
            $phpResult = "PHP - array_chunk: ";
            $chunks = array_chunk($inputArray, 2);
            foreach ($chunks as $chunk) {
                $phpResult .= "[" . implode(", ", $chunk) . "] ";
            }
            break;
        case 'array_key_exists':
            $phpResult = "PHP - array_key_exists(1): " . (array_key_exists(1, $inputArray) ? "True" : "False");
            break;
        case 'end':
            $phpResult = "PHP - end(): " . end($inputArray);
            break;
        case 'count':
            $phpResult = "PHP - count(): " . count($inputArray);
            break;
        case 'shuffle':
            shuffle($inputArray);
            $phpResult = "PHP - shuffle(): " . implode(", ", $inputArray);
            break;
        default:
            $phpResult = "Please select a valid PHP function.";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Functions - PHP and JavaScript</title>
    <link rel="stylesheet" href="./assets/css/style.css">
   <script src="./assets/js/script.js"></script>
</head>
<body>

    <div class="container">
        <header>
            <h1>Array Functions - PHP and JavaScript</h1>
        </header>

        <div class="content">
            <!-- PHP Form Section -->
            <div class="function-section php-functions">
                <h2>PHP Array Functions</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="inputArray">Enter Array (comma-separated values):</label>
                        <input type="text" id="inputArray" name="inputArray" value="" placeholder="Enter array items">
                    </div>

                    <div class="form-group">
                        <label for="function">Select PHP Function:</label>
                        <select id="function" name="function">
                            <option value="sort">sort</option>
                            <option value="rsort">rsort</option>
                            <option value="asort">asort</option>
                            <option value="arsort">arsort</option>
                            <option value="ksort">ksort</option>
                            <option value="krsort">krsort</option>
                            <option value="usort">usort</option>
                            <option value="ursort">ursort</option>
                            <option value="uksort">uksort</option>
                            <option value="in_array">in_array</option>
                            <option value="is_array">is_array</option>
                            <option value="array_chunk">array_chunk</option>
                            <option value="array_key_exists">array_key_exists</option>
                            <option value="end">end</option>
                            <option value="count">count</option>
                            <option value="shuffle">shuffle</option>
                        </select>
                    </div>

                    <button type="submit">Apply PHP Function</button>

                    <div class="result">
                        <h3>Result:</h3>
                        <p><?= $phpResult ?></p>
                    </div>
                </form>
            </div>

            <!-- JavaScript Form Section -->
            <div class="function-section js-functions">
                <h2>JavaScript Array Functions</h2>
                <div class="form-group">
                    <label for="jsInputArray">Enter Array (comma-separated values):</label>
                    <input type="text" id="jsInputArray" placeholder="Enter array items">
                </div>

                <div class="form-group">
                    <label for="jsFunction">Select JavaScript Function:</label>
                    <select id="jsFunction">
                        <option value="sort">sort</option>
                        <option value="reverse">reverse</option>
                        <option value="push">push</option>
                        <option value="pop">pop</option>
                        <option value="length">length</option>
                        <option value="shift">shift</option>
                        <option value="unshift">unshift</option>
                        <option value="splice">splice</option>
                        <option value="indexOf">indexOf</option>
                    </select>
                </div>

                <button type="button" onclick="applyJsFunction()">Apply JavaScript Function</button>

                <div class="result">
                    <h3>Result:</h3>
                    <p id="jsResult"></p>
                </div>
            </div>
        </div>

    </div>

</body>
</html>