<?php
// PHP string functions
$phpResult = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $inputString = isset($_POST['inputString']) ? $_POST['inputString'] : "";
    $function = isset($_POST['function']) ? $_POST['function'] : "";

    switch ($function) {
        case 'addslashes':
            $phpResult = "PHP - addslashes(): " . addslashes($inputString);
            break;
        case 'stripslashes':
            $phpResult = "PHP - stripslashes(): " . stripslashes($inputString);
            break;
        case 'md5':
            $phpResult = "PHP - md5(): " . md5($inputString);
            break;
        case 'strpos':
            $phpResult = "PHP - strpos(): " . strpos($inputString, "World");
            break;
        case 'stripos':
            $phpResult = "PHP - stripos(): " . stripos($inputString, "world");
            break;
        case 'str_replace':
            $phpResult = "PHP - str_replace(): " . str_replace("World", "PHP", $inputString);
            break;
        case 'strip_tags':
            $phpResult = "PHP - strip_tags(): " . strip_tags("<p>Hello</p>");
            break;
        case 'strrev':
            $phpResult = "PHP - strrev(): " . strrev($inputString);
            break;
        case 'strlen':
            $phpResult = "PHP - strlen(): " . strlen($inputString);
            break;
        case 'trim':
            $phpResult = "PHP - trim(): " . trim($inputString);
            break;
        case 'ltrim':
            $phpResult = "PHP - ltrim(): " . ltrim($inputString);
            break;
        case 'rtrim':
            $phpResult = "PHP - rtrim(): " . rtrim($inputString);
            break;
        case 'sprintf':
            $phpResult = "PHP - sprintf(): " . sprintf("Hello, %s!", "World");
            break;
        case 'substr':
            $phpResult = "PHP - substr(): " . substr($inputString, 7);
            break;
        case 'implode':
            $phpResult = "PHP - implode(): " . implode(", ", explode(",", "Apple,Banana,Cherry"));
            break;
        case 'explode':
            $phpResult = "PHP - explode(): " . implode(", ", explode(",", $inputString));
            break;
        case 'nl2br':
            $phpResult = "PHP - nl2br(): " . nl2br("Line 1\nLine 2");
            break;
        case 'preg_match':
            preg_match("/World/", $inputString, $matches);
            $phpResult = "PHP - preg_match(): " . implode(", ", $matches);
            break;
        case 'preg_match_all':
            preg_match_all("/o/", $inputString, $matches);
            $phpResult = "PHP - preg_match_all(): " . implode(", ", $matches[0]);
            break;
        case 'preg_replace':
            $phpResult = "PHP - preg_replace(): " . preg_replace("/World/", "PHP", $inputString);
            break;
        default:
            $phpResult = "Please select a valid PHP function.";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>String Functions - PHP and JavaScript</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <script src="./assets/js/script.js"></script>

</head>
<body>

    <div class="container">
        <header>
            <h1>String Functions - PHP and JavaScript</h1>
        </header>

        <div class="content">
            <!-- PHP Form Section -->
            <div class="function-section php-functions">
                <h2>PHP String Functions</h2>
                <form method="post">
                    <div class="form-group">
                        <label for="inputString">Enter String:</label>
                        <input type="text" id="inputString" name="inputString" value="" placeholder="Enter your string here">
                    </div>

                    <div class="form-group">
                        <label for="function">Select PHP Function:</label>
                        <select id="function" name="function">
                            <option value="addslashes">addslashes</option>
                            <option value="stripslashes">stripslashes</option>
                            <option value="md5">md5</option>
                            <option value="strpos">strpos</option>
                            <option value="stripos">stripos</option>
                            <option value="str_replace">str_replace</option>
                            <option value="strip_tags">strip_tags</option>
                            <option value="strrev">strrev</option>
                            <option value="strlen">strlen</option>
                            <option value="trim">trim</option>
                            <option value="ltrim">ltrim</option>
                            <option value="rtrim">rtrim</option>
                            <option value="sprintf">sprintf</option>
                            <option value="substr">substr</option>
                            <option value="implode">implode</option>
                            <option value="explode">explode</option>
                            <option value="nl2br">nl2br</option>
                            <option value="preg_match">preg_match</option>
                            <option value="preg_match_all">preg_match_all</option>
                            <option value="preg_replace">preg_replace</option>
                        </select>
                    </div>

                    <button type="submit">Apply PHP Function</button>

                    <div class="result">
                        <h3>Result:</h3>
                        <p><?= $phpResult ?></p>
                    </div>
                </form>
            </div>

            <!-- JavaScript Form Section -->
            <div class="function-section js-functions">
                <h2>JavaScript String Functions</h2>
                <div class="form-group">
                    <label for="jsInputString">Enter String:</label>
                    <input type="text" id="jsInputString" placeholder="Enter string here">
                </div>

                <div class="form-group">
                    <label for="jsFunction">Select JavaScript Function:</label>
                    <select id="jsFunction">
                        <option value="length">length</option>
                        <option value="replace">replace</option>
                        <option value="toUpperCase">toUpperCase</option>
                        <option value="toLowerCase">toLowerCase</option>
                        <option value="trim">trim</option>
                        <option value="substring">substring</option>
                        <option value="slice">slice</option>
                        <option value="concat">concat</option>
                        <option value="indexOf">indexOf</option>
                        <option value="lastIndexOf">lastIndexOf</option>
                        <option value="search">search</option>
                        <option value="match">match</option>
                        <option value="test">test</option>
                    </select>
                </div>

                <button type="button" onclick="applyJsFunction()">Apply JavaScript Function</button>

                <div class="result">
                    <h3>Result:</h3>
                    <p id="jsResult"></p>
                </div>
            </div>
        </div>

    </div>

</body>
</html>
