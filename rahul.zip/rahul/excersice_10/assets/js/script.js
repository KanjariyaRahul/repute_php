function applyJsFunction() {
    let str = document.getElementById("jsInputString").value;
    let func = document.getElementById("jsFunction").value;
    let result;

   
    switch (func) {
        // Case for 'length' function
        case "length":
            // Returns the length of the string
            result = "JavaScript - length: " + str.length;
            break;

        // Case for 'replace' function
        case "replace":
            // Replaces 'world' with 'JavaScript' in the string
            result = "JavaScript - replace: " + str.replace("world", "JavaScript");
            break;

        // Case for 'toUpperCase' function
        case "toUpperCase":
            // Converts the string to uppercase
            result = "JavaScript - toUpperCase: " + str.toUpperCase();
            break;

        // Case for 'toLowerCase' function
        case "toLowerCase":
            // Converts the string to lowercase
            result = "JavaScript - toLowerCase: " + str.toLowerCase();
            break;

        // Case for 'trim' function
        case "trim":
            // Removes whitespace from both ends of the string
            result = "JavaScript - trim: " + str.trim();
            break;

        // Case for 'substring' function
        case "substring":
            // Extracts a substring starting from index 7 to the end of the string
            result = "JavaScript - substring: " + str.substring(7);
            break;

        // Case for 'slice' function
        case "slice":
            // Extracts part of the string starting from index 7 to the end
            result = "JavaScript - slice: " + str.slice(7);
            break;

        // Case for 'concat' function
        case "concat":
            // Concatenates another string (" Welcome!") to the original string
            result = "JavaScript - concat: " + str.concat(" Welcome!");
            break;

        // Case for 'indexOf' function
        case "indexOf":
            // Finds the index of the first occurrence of "World" in the string
            result = "JavaScript - indexOf: " + str.indexOf("World");
            break;

        // Case for 'lastIndexOf' function
        case "lastIndexOf":
            // Finds the index of the last occurrence of the character "o"
            result = "JavaScript - lastIndexOf: " + str.lastIndexOf("o");
            break;

        // Case for 'search' function
        case "search":
            // Searches the string for the substring "World" using regular expression
            result = "JavaScript - search: " + str.search("World");
            break;

        // Case for 'match' function
        case "match":
            // Finds all occurrences of the character "o" using regular expression
            result = "JavaScript - match: " + str.match(/o/g);
            break;

        // Case for 'test' function
        case "test":
            // Tests if the regular expression "World" exists in the string
            let regex = /World/;
            result = "JavaScript - test: " + regex.test(str);
            break;

        default:
            result = "Please select a valid JavaScript function.";
            break;
    }

    document.getElementById("jsResult").innerHTML = "<p><strong>Result:</strong> " + result + "</p>";
}
