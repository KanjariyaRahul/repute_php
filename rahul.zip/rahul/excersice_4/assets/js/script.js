"use strict";

document.getElementById("submitForm").addEventListener("click", function(event) {
    event.preventDefault(); 

    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;
    const age = document.getElementById("age").value;

    let isValid = true;
    let errorMessage = '';

    // Name Validation (non-empty check)
    if (name.trim() === '') {
        isValid = false;
        errorMessage += 'Name is required.\n';
    }

    // Phone Validation
    const phoneRegex = /^[0-9]{10}$/; 
    if (!phoneRegex.test(phone)) {
        isValid = false;
        errorMessage += 'Phone number must be exactly 10 digits.\n';
    }

    // Email Validation 
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailRegex.test(email)) {
        isValid = false;
        errorMessage += 'Please enter a valid email address.\n';
    }

    // Age Validation 
    const ageValue = parseInt(age, 10);
    if (isNaN(ageValue) || ageValue <= 0) {
        isValid = false;
        errorMessage += 'Age must be a positive number.\n';
    }


    if (isValid) {
        document.getElementById("result").textContent = "Form submitted successfully!";
    } else {
        document.getElementById("result").textContent = errorMessage;
    }
});
