Using a variable, without declaring it, is not allowed:

Using an object, without declaring it, is not allowed:

Deleting a variable (or object) is not allowed.

Deleting a function is not allowed.

Duplicating a parameter name is not allowed:

Octal numeric literals are not allowed:

Octal escape characters are not allowed:

Writing to a read-only property is not allowed: 

Writing to a get-only property is not allowed:

Deleting an undeletable property is not allowed:

The word eval cannot be used as a variable:

The word arguments cannot be used as a variable:

For security reasons, eval() is not allowed to create variables in the scope from which it was called.


// Enabling strict mode globally
// "use strict";

// // Function with strict mode-related rules
// function StrictMode() {
//     // 1. Using a variable, without declaring it, is not allowed:
//     try {
//         undeclaredVar = 10; 
//     } catch (e) {
//         console.error("Error: Using undeclared variable:", e.message);
//     }

//     // 2. Using an object, without declaring it, is not allowed:
//     try {
//         obj = { name: "Strict Mode Example" }; 
//     } catch (e) {
//         console.error("Error: Using undeclared object:", e.message);
//     }

//     // 3. Deleting a variable (or object) is not allowed:
//     try {
//         let x = 5;
//         delete x; 
//     } catch (e) {
//         console.error("Error: Deleting a variable:", e.message);
//     }

//     // 4. Deleting a function is not allowed:
//     try {
//         function testFunc() { console.log("Test function"); }
//         delete testFunc; 
//     } catch (e) {
//         console.error("Error: Deleting a function:", e.message);
//     }

//     // 5. Duplicating a parameter name is not allowed:
//     try {
//         function duplicateParams(a, a) { return a; }
//     } catch (e) {
//         console.error("Error: Duplicating parameter name:", e.message);
//     }

//     // 6. Octal numeric literals are not allowed:
//     try {
//         let num = 010; 
//     } catch (e) {
//         console.error("Error: Octal numeric literal:", e.message);
//     }

//     // 7. Octal escape characters are not allowed:
//     try {
//         let str = "\010";
//     } catch (e) {
//         console.error("Error: Octal escape character:", e.message);
//     }

//     // 8. Writing to a read-only property is not allowed:
//     try {
//         const obj = Object.freeze({ a: 1 });
//         obj.a = 10;
//     } catch (e) {
//         console.error("Error: Writing to a read-only property:", e.message);
//     }

//     // 9. Writing to a get-only property is not allowed:
//     try {
//         const obj = {
//             get readOnly() {
//                 return 42;
//             }
//         };
//         obj.readOnly = 10; 
//     } catch (e) {
//         console.error("Error: Writing to a get-only property:", e.message);
//     }

//     // 10. Deleting an undeletable property is not allowed:
//     try {
//         const obj = {};
//         Object.defineProperty(obj, 'undeletable', {
//             value: 10,
//             configurable: false
//         });
//         delete obj.undeletable; 
//     } catch (e) {
//         console.error("Error : Deleting an undeletable property:", e.message);
//     }

//     // 11. The word 'eval' cannot be used as a variable:
//     try {
//         let eval = 100; 
//     } catch (e) {
//         console.error("Error: 'eval' cannot be used as a variable:", e.message);
//     }

//     // 12. The word 'arguments' cannot be used as a variable:
//     try {
//         let arguments = "Hello"; 
//     } catch (e) {
//         console.error("Error: 'arguments' cannot be used as a variable:", e.message);
//     }

//     // 13. For security reasons, eval() is not allowed to create variables in the scope from which it was called:
//     try {
//         eval("var foo = 'bar';"); 
//     } catch (e) {
//         console.error("Error: eval() cannot create variables:", e.message);
//     }
// }

// // Call the function to show the strict mode behavior
// StrictMode();


"use strict";

document.addEventListener('DOMContentLoaded', function () {
    function StrictMode() {
        // 1. Using a variable, without declaring it, is not allowed:
        try {
            undeclaredVar = 10; 
        } catch (e) {
            console.error("Error: Using undeclared variable:", e.message);
        }


        document.getElementById('submitForm').addEventListener('click', function () {
            // User Input: Check if number input is a valid number
            let num1 = parseFloat(document.getElementById('number1').value);
            let num2 = parseFloat(document.getElementById('number2').value);

            try {
                if (isNaN(num1) || isNaN(num2)) {
                    throw new Error("Please enter valid numbers.");
                }
                let sum = num1 + num2;
                document.getElementById('result').innerText = "Sum: " + sum;
            } catch (e) {
                document.getElementById('result').innerText = "Error: " + e.message;
            }
        });
    }

    // Call the function to show the strict mode behavior
    StrictMode();
});

