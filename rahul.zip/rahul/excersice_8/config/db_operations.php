<?php
include('connect.php');

function getAllUsers() {
    global $conn;
    $sql = "SELECT * FROM user"; 
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return [];
    }
}

function saveUser($first_name, $last_name, $email, $phone, $file) {
    global $conn;
    $sql = "INSERT INTO user (first_name, last_name, email, phone, file) 
            VALUES ('$first_name', '$last_name', '$email', '$phone', '$file')";
    
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = "User saved successfully!";
        $_SESSION['message_type'] = "success";
        header('Location: index.php');
        exit();
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['message_type'] = "error";
        header('Location: index.php');
        exit();
    }
}



function checkUserCredentials($username, $password) {
    global $conn;
    $username = mysqli_real_escape_string($conn, $username);
    $sql = "SELECT id, username, password FROM admin WHERE username = '$username'";

    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if ($password == $row['password']) {
            return ['id' => $row['id'], 'username' => $row['username']];
        }
    }
    return false;
}

function saveRememberTokenToDatabase($userId, $hashedToken) {
    global $conn;
    $userId = (int)$userId;  // Ensure $userId is an integer to prevent SQL injection
    $sql = "UPDATE admin SET remember_token = '$hashedToken' WHERE id = $userId";
    mysqli_query($conn, $sql);
}




?>
