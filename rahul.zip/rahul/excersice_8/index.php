<?php
session_start();

include('includes/header.php');
include('config/db_operations.php');

$users = getAllUsers(); 

$result = mysqli_query($conn, "SELECT * FROM products");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
        $productId = (int)$_POST['add_to_cart'];
        $quantity = 1;

        $checkCart = mysqli_query($conn, "SELECT * FROM cart WHERE user_id = $userId AND product_id = $productId");
        
        if (mysqli_num_rows($checkCart) > 0) {
            mysqli_query($conn, "UPDATE cart SET quantity = quantity + 1 WHERE user_id = $userId AND product_id = $productId");
        } else {
            mysqli_query($conn, "INSERT INTO cart (user_id, product_id, quantity) VALUES ($userId, $productId, $quantity)");
        }
        
        header("Location: cart.php");
        exit;
    } else {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header("Location: ./auth/login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link rel="stylesheet" href="../../style.css">
</head>
<body>
    <div class="pro-container">
         <h1>Product List</h1>
        <div class="product-container">
            <?php while ($product = mysqli_fetch_assoc($result)): ?>
                <div class="product-card">
                    <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <p class="price"> ₹.<?php echo htmlspecialchars($product['price']); ?></p>
                    <form method="POST" action="">
                        <button type="submit" name="add_to_cart" value="<?php echo $product['id']; ?>">Add to Cart</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>

<?php
include('includes/footer.php');
?>
