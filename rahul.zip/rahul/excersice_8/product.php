<?php
session_start();
include('./config/connect.php');

// Fetch all products
$result = mysqli_query($conn, "SELECT * FROM products");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
</head>
<body>
    <h1>Product List</h1>
    
    <?php while ($product = mysqli_fetch_assoc($result)): ?>
        <div class="product-card">
            <h2><?php echo htmlspecialchars($product['name']); ?></h2>
            <p><?php echo htmlspecialchars($product['description']); ?></p>
            <p>Price: $<?php echo htmlspecialchars($product['price']); ?></p>
            <!-- Add to Cart Button -->
            <form method="POST" action="product.php?product_id=<?php echo $product['id']; ?>">
                <button type="submit" name="add_to_cart" value="<?php echo $product['id']; ?>">Add to Cart</button>
            </form>
        </div>
    <?php endwhile; ?>
</body>
</html>

<?php
// Handle Add to Cart functionality
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    // Check if user is logged in
    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
        $productId = (int)$_POST['add_to_cart'];
        $quantity = 1;  // Default quantity

        // Check if product already exists in the user's cart
        $checkCart = mysqli_query($conn, "SELECT * FROM cart WHERE user_id = $userId AND product_id = $productId");
        
        if (mysqli_num_rows($checkCart) > 0) {
            // If the product is already in the cart, update the quantity
            mysqli_query($conn, "UPDATE cart SET quantity = quantity + 1 WHERE user_id = $userId AND product_id = $productId");
        } else {
            // If the product is not in the cart, add it
            mysqli_query($conn, "INSERT INTO cart (user_id, product_id, quantity) VALUES ($userId, $productId, $quantity)");
        }
        
        // Redirect to the cart page
        header("Location: cart.php");
        exit;
    } else {
        // If the user is not logged in, redirect to the login page
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];  // Save current URL to redirect after login
        // header("Location: login.php");
        exit;
    }
}
?>