<?php
session_start();
include('./config/connect.php');


if (!isset($_SESSION['user_id']) && !isset($_COOKIE['remember_token'])) {
    header("Location: ./login.php");
    exit;
}

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $result = mysqli_query($conn, "SELECT * FROM cart INNER JOIN products ON cart.product_id = products.id WHERE cart.user_id = $userId");
    $cartItems = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    $cartItems = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
}
?>

<h1>Your Cart</h1>
<table id="cart-table">
    <thead>
        <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total Price</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($cartItems as $item) { ?>
            <tr id="product-<?php echo $item['product_id']; ?>">
                <td><?php echo htmlspecialchars($item['name']); ?></td>
                <td>
                    <button class="decrement" data-product-id="<?php echo $item['product_id']; ?>">-</button>
                    <span id="quantity-<?php echo $item['product_id']; ?>"><?php echo $item['quantity']; ?></span>
                    <button class="increment" data-product-id="<?php echo $item['product_id']; ?>">+</button>
                </td>
                <td>Rs. <span class="price" data-price="<?php echo $item['price']; ?>"><?php echo htmlspecialchars($item['price']); ?></span></td>
                <td>Rs. <span id="total-<?php echo $item['product_id']; ?>"><?php echo $item['price'] * $item['quantity']; ?></span></td>

            </tr>
        <?php } ?>
    </tbody>
</table>




<script>
document.addEventListener('DOMContentLoaded', function() {
    const incrementButtons = document.querySelectorAll('.increment');
    const decrementButtons = document.querySelectorAll('.decrement');
    const removeButtons = document.querySelectorAll('.remove');

   
    incrementButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            let quantity = parseInt(document.getElementById('quantity-' + productId).textContent);
            quantity++;

            document.getElementById('quantity-' + productId).textContent = quantity;
            updateTotalPrice(productId, quantity);

            updateCartQuantity(productId, quantity);
        });
    });


    decrementButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            let quantity = parseInt(document.getElementById('quantity-' + productId).textContent);
            if (quantity > 1) {
                quantity--;


                document.getElementById('quantity-' + productId).textContent = quantity;
                updateTotalPrice(productId, quantity);
                updateCartQuantity(productId, quantity);
            }
        });
    });


    function updateTotalPrice(productId, quantity) {
        const price = parseFloat(document.querySelector('#product-' + productId + ' .price').getAttribute('data-price'));
        const total = price * quantity;
        document.getElementById('total-' + productId).textContent = total.toFixed(2);

     
        let totalPrice = 0;
        document.querySelectorAll('.price').forEach((priceElement, index) => {
            const row = priceElement.closest('tr');
            const rowQuantity = parseInt(row.querySelector('.quantity span').textContent);
            const rowPrice = parseFloat(priceElement.getAttribute('data-price'));
            totalPrice += rowPrice * rowQuantity;
        });
        document.getElementById('total-price').textContent = totalPrice.toFixed(2);
    }
    
});
</script>
