<?php
session_start();
include('../config/connect.php');

if (isset($_COOKIE['remember_token'])) {
    $rememberToken = $_COOKIE['remember_token'];
    $result = mysqli_query($conn, "SELECT * FROM user WHERE remember_token = '$rememberToken'");
    $user = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $rememberMe = isset($_POST['remember_me']) ? true : false;

    $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        $currentTime = time();
        $failedAttempts = isset($user['failed_attempts']) ? $user['failed_attempts'] : 0;
        $lastFailedAttempt = isset($user['last_failed_attempt']) ? strtotime($user['last_failed_attempt']) : 0;
        $lockoutTime = 60 * 15;

        if ($failedAttempts >= 3 && ($currentTime - $lastFailedAttempt) < $lockoutTime) {
            $error = "Too many failed attempts. Please try again later.";
        } else {
            if ($password == $user['password']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                mysqli_query($conn, "UPDATE user SET failed_attempts = 0 WHERE id = " . $user['id']);

                if ($rememberMe) {
                    $rememberToken = bin2hex(random_bytes(16));
                    setcookie('remember_token', $rememberToken, time() + (86400 * 30), "/");
                    mysqli_query($conn, "UPDATE user SET remember_token = '$rememberToken' WHERE id = " . $user['id']);
                }

                header("Location: " . ($_SESSION['redirect_url'] ?? '../index.php'));
                exit;
            } else {
                $failedAttempts++;
                mysqli_query($conn, "UPDATE user SET failed_attempts = $failedAttempts, last_failed_attempt = NOW() WHERE id = " . $user['id']);
                $error = "Invalid username or password!";
            }
        }
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            padding: 10px;
            text-align: center;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            font-size: 18px;
        }

        .navbar a:hover {
            text-decoration: underline;
        }

        h2 {
            text-align: center;
            margin-top: 50px;
            font-size: 24px;
        }

        .login-form {
            width: 100%;
            max-width: 400px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .input {
            width: 92%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        .login-form button {
            width: 100%;
            padding: 12px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .login-form button:hover {
            background-color: #444;
        }

        .remember-me {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            margin: 10px 0;
        }

        .remember-me input {
            margin-right: 10px;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <a href="../index.php">Home</a>
        </div>
    </header>

    <h2>Login</h2>
    
    <div class="login-form">
        <form method="POST" action="login.php" id="loginForm">
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
            <input type="text" class="input" name="username" placeholder="Username" id="username" required>
            <input type="password" class="input" name="password" placeholder="Password" id="password" required>
            <div class="remember-me">
                <input type="checkbox" name="remember_me" id="remember">
                <label for="remember">Remember Me</label>
            </div>
            <button type="submit">Login</button>
        </form>

    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            var username = document.getElementById('username').value;
            var password = document.getElementById('password').value;
            var rememberMe = document.getElementById('remember').checked;

            if (username === "" || password === "") {
                alert("Username and Password are required.");
                event.preventDefault();
            }

            if (rememberMe === false) {
                alert("Please check the 'Remember Me' checkbox.");
                event.preventDefault();
            }
        });
    </script>
</body>
</html>