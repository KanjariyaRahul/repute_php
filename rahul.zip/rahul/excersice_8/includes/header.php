<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();  // Start the session only if it hasn't started yet
}
include('./config/connect.php');


if (isset($_SESSION['user_id']) ) {
    $isLoggedIn = true;
} else {
    $isLoggedIn = false;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1>RK Shoping</h1>
            <nav>
                <?php if ($isLoggedIn): ?>
                    <a href="./auth/logout.php">Logout</a>
                <?php else: ?>
                    <a href="./auth/login.php">Login</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
</body>
</html>
