
<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

   
    $query = "DELETE FROM user WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    session_start();
    if ($result) {
        
        header("Location: manageusers.php?message=User+deleted+successfully!");
        exit();
    } else {   
        header("Location: manageusers.php?message=Error+deleting+user.");
        exit();
    }
}
?>
 